# Flask

## General Description

1. Version 1: berisi project tanpa database
2. Version 2: berisi project dengan database
3. Version 3: berisi project dengan database latihan

Jalankan dengan command `python app.py` pada tiap version.

`localhost:5000` pada browser untuk halaman utama, dan `http://localhost:5000/api/ui` untuk dokumentasi API.
